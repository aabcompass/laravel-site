<?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
        // Запрещаем выбирать саму себя
        $isDisabled = ($t->id == $currentId) ? 'disabled' : ''; 
    ?>
    <option value="<?php echo e($t->id); ?>" <?php echo e($t->id == $selectedId ? 'selected' : ''); ?> <?php echo e($isDisabled); ?>>
        <?php echo str_repeat('&nbsp;&nbsp;&nbsp;', $level); ?> <?php echo e($t->name); ?>

    </option>
    <?php if($t->children->count() > 0): ?>
        <?php echo $__env->make('sources.options', ['sources' => $t->children, 'level' => $level + 1, 'selectedId' => $selectedId, 'currentId' => $currentId], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/resources/views/sources/options.blade.php ENDPATH**/ ?>
<li class="p-2 <?php echo e($level === 0 ? 'bg-gray-50 border rounded mb-4 shadow-sm' : 'hover:bg-gray-100 rounded mt-1'); ?>">
    <div class="flex justify-between items-center">
        <div>
            <span class="<?php echo e($level === 0 ? 'font-bold text-lg text-blue-600' : 'text-gray-700'); ?>">
                <?php echo e($source->name); ?>

            </span>
            <?php if($source->description && $level === 0): ?>
                <div class="text-sm text-gray-500"><?php echo e($source->description); ?></div>
            <?php endif; ?>
        </div>
        
        <!-- ЕДИНСТВЕННЫЙ БЛОК С КНОПКАМИ -->
        <div class="space-x-3 text-sm flex items-center">
            
            <!-- КНОПКИ ВВЕРХ / ВНИЗ -->
            <div class="flex items-center gap-1 mr-2 border-r border-gray-300 pr-4">
                <form action="<?php echo e(route('sources.move', [$source->id, 'up'])); ?>" method="POST" class="m-0">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="w-7 h-7 flex items-center justify-center bg-gray-500 hover:bg-gray-700 text-white rounded-full transition-colors text-xs shadow-sm" title="Вверх">
                        ▲
                    </button>
                </form>
                <form action="<?php echo e(route('sources.move', [$source->id, 'down'])); ?>" method="POST" class="m-0">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="w-7 h-7 flex items-center justify-center bg-gray-500 hover:bg-gray-700 text-white rounded-full transition-colors text-xs shadow-sm" title="Вниз">
                        ▼
                    </button>
                </form>
            </div>

            <!-- Ссылки -->
            <a href="<?php echo e(route('sources.create', ['parent_id' => $source->id])); ?>" class="text-blue-600 hover:text-blue-800 hover:underline">Добавить дочерний источник</a>
            
            <a href="<?php echo e(route('sources.edit', $source->id)); ?>" class="text-gray-600 hover:text-gray-800 hover:underline">Изменить</a>
            
            <form action="<?php echo e(route('sources.destroy', $source->id)); ?>" method="POST" class="inline m-0" onsubmit="return confirm('Удалить этот источник? Дочерние источники станут корневыми.')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-red-500 hover:text-red-700 hover:underline cursor-pointer">Удалить</button>
            </form>

        </div>

    </div>

    <?php if($source->children->count() > 0): ?>
        <ul class="ml-6 border-l-2 border-gray-200 pl-4 mt-2">
            <?php $__currentLoopData = $source->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('sources.item', ['source' => $child, 'level' => $level + 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li><?php /**PATH /var/www/resources/views/sources/item.blade.php ENDPATH**/ ?>